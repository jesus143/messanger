@extends('app')

@section('content')
<div class="container">
	<div class="row">
		<div class="col-md-10 col-md-offset-1">
			<div class="panel panel-default">
				<div class="panel-heading">Activity</div>

				<div class="panel-body">
					Welcome, this app will allow you to send sms to your co-worker, you just need internet connection and thats all!
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
